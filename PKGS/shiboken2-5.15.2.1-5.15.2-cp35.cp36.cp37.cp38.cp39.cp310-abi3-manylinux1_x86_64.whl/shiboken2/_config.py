shiboken_library_soversion = str(5.15)

version = "5.15.2.1"
version_info = (5, 15, 2.1, "", "")

__build_date__ = '2022-01-07T14:24:23+00:00'




__setup_py_package_version__ = '5.15.2.1'
