'''
The compiler is not implemented in the simulator. This module provides a stub
to allow tests to import successfully.
'''

compile_ptx = None
compile_ptx_for_current_device = None
