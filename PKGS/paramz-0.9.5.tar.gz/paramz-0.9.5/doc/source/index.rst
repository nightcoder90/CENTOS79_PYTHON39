.. paramz documentation master file, created by
   sphinx-quickstart on Wed Oct 14 18:55:28 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Developer Documentation
=======================

.. toctree::

   paramz

