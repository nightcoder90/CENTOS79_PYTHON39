# Copyright (c) 2016, the GPyOpt Authors
# Licensed under the BSD 3-clause license (see LICENSE.txt)

from . import experiments1d
from . import experiments2d
from . import experimentsNd
