To install a python package run:

	python setup.py install