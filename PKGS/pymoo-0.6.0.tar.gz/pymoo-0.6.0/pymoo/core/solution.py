from pymoo.core.individual import Individual
from pymoo.core.population import Population


class Solution(Individual):
    pass


class SolutionSet(Population):
    pass
