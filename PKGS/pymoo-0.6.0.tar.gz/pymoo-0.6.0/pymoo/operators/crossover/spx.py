from pymoo.operators.crossover.pntx import SinglePointCrossover


class SPX(SinglePointCrossover):
    pass
